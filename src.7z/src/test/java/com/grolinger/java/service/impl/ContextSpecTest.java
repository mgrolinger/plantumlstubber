package com.grolinger.java.service.impl;

import com.grolinger.java.controller.templatemodel.Constants;
import com.grolinger.java.service.data.mapper.ColorMapper;
import org.springframework.util.StringUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.thymeleaf.context.Context;

import java.time.LocalDate;

import static com.grolinger.java.controller.templatemodel.ContextVariables.*;
import static org.assertj.core.api.Assertions.assertThat;

public class ContextSpecTest {
    @DataProvider
    public Object[][] getTestBuilder() {
        final String applicationName = "testApplication";
        final String serviceName = "testServiceName/withSeparator.v2";
        final String serviceNameAfterConversion = "TestServiceNameWithSeparatorV2";
        final String colorName = "integration";
        final String integrationType = "TestIntegration";
        final String interfaceName = "testInterfaceName";
        final String commonPath = "../testCommonPath";

        //@formatter:off
        return new Object[][]{
                {false, applicationName,serviceName,colorName,integrationType,interfaceName},
                {true,  applicationName,"EMPTY",    colorName,integrationType,interfaceName}
        };
        //@formatter:on
    }

    @Test(dataProvider = "getTestBuilder")
    public void testBuilder(final boolean isRootService, final String applicationName, final String serviceName, final String colorName, final String integrationType, final String interfaceName) {

        final String serviceNameAfterConversion = "TestServiceNameWithSeparatorV2";
        final String commonPath = "../testCommonPath";

        Context result = new ContextSpec().builder()
                .withColorName(colorName)
                .withIntegrationType(integrationType)
                .withApplicationName(applicationName)
                .withPreformattedServiceName(serviceName)
                .withInterfaceName(interfaceName)
                .withCommonPath(commonPath)
                .withOrderPrio(1)
                .getContext();

        assertThat(result.getVariable(DATE_CREATED.getName())).isEqualTo(LocalDate.now());
        assertThat(result.getVariable(COLOR_NAME.getName())).isEqualTo(ColorMapper.getDomainColor(colorName));
        assertThat(result.getVariable(COLOR_TYPE.getName())).isEqualTo(ColorMapper.getStereotype(colorName));
        assertThat(result.getVariable(CONNECTION_COLOR.getName())).isEqualTo(ColorMapper.getConnectionColor(colorName));
        assertThat(result.getVariable(COMPONENT_INTEGRATION_TYPE.getName())).isEqualTo("INTEGRATION_TYPE(" + integrationType + ")");
        assertThat(result.getVariable(IS_ROOT_SERVICE.getName())).isEqualTo(isRootService);
        assertThat(result.getVariable(IS_SOAP_SERVICE.getName())).isEqualTo(false);
        assertThat(result.getVariable(APPLICATION_NAME.getName())).isEqualTo(StringUtils.capitalize(applicationName));
        assertThat(result.getVariable(ALIAS.getName())).isEqualTo(applicationName.toLowerCase());
        String expectedAPI;

        String expectedCompleteInterfaceName;
        if (isRootService){
            assertThat(result.getVariable(SERVICE_NAME.getName())).isEqualTo("");
            expectedAPI = (applicationName + "_API_" + interfaceName + "_CREATED").toUpperCase();
            expectedCompleteInterfaceName = StringUtils.capitalize(applicationName) + StringUtils.capitalize(interfaceName) + "Int";
        }else{
            assertThat(result.getVariable(SERVICE_NAME.getName())).isEqualTo(serviceName.replace(".", Constants.NAME_SEPARATOR.getValue()));
            expectedAPI = (applicationName + "_API_" + serviceName.replace(Constants.SLASH.getValue(), Constants.NAME_SEPARATOR.getValue()).replace(Constants.DOT_SEPARATOR.getValue(), Constants.NAME_SEPARATOR.getValue()) + "_" + interfaceName + "_CREATED").toUpperCase();
            expectedCompleteInterfaceName = StringUtils.capitalize(applicationName) + serviceNameAfterConversion + StringUtils.capitalize(interfaceName) + "Int";
        }
        assertThat(result.getVariable(INTERFACE_NAME.getName())).isEqualTo(interfaceName);
        assertThat(result.getVariable(COMPLETE_INTERFACE_NAME.getName())).isEqualTo(expectedCompleteInterfaceName);
        assertThat(result.getVariable(SEQUENCE_PARTICIPANT_ORDER.getName())).isEqualTo(1);
        assertThat(result.getVariable(PATH_TO_COMMON_FILE.getName())).isEqualTo(commonPath);
        assertThat(result.getVariable(SEQUENCE_PARTICIPANT_ORDER.getName())).isEqualTo(1);



        assertThat(result.getVariable(API_CREATED.getName())).isEqualTo(expectedAPI);

    }
}