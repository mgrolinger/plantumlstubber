package com.grolinger.java.service.data;

import com.grolinger.java.controller.templatemodel.Constants;
import org.springframework.util.StringUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import static org.assertj.core.api.Assertions.assertThat;

public class ServiceEndpointTest {

    @DataProvider
    public Object[][] getServiceCallNameDataProvider() {
        return new Object[][]{
                //@formatter:off
                {"serviceName",              "ServiceName"},
                {Constants.EMPTY.getValue(), ""}
                //@formatter:on
        };
    }

    @Test(dataProvider = "getServiceCallNameDataProvider")
    public void testGetServiceCallNameDataProvider(final String serviceName,
                                                   final String expectedValue) {
        ServiceEndpoint cut = new ServiceEndpoint("applicationName", serviceName, "", "integration", 0, "SOAP::XML");
        String result = cut.getServiceCallName();
        assertThat(result).isEqualTo(expectedValue);
    }

    @DataProvider
    public Object[][] testGetFormattedServiceNameDataProvider() {
        final String application = "applicationName";
        final String serviceName = "serviceName";
        final String capServiceName = StringUtils.capitalize(serviceName);
        final String serviceNameWithUnwantedChars = "restServiceName/subservice/interface";
        final String soapServiceNameWithUnwantedChars = "soapServiceName/subservice/interface";
        final boolean isSoap = true;
        final boolean notSoap = false;
        return new Object[][]{
                //@formatter:off
                { application, null,         "SOAP::XML",    Constants.DEFAULT_ROOT_SERVICE_NAME.getValue() },
                { application, null,         "REST::JSON",   Constants.DEFAULT_ROOT_SERVICE_NAME.getValue() },
                { application, "",           "SOAP::XML",    Constants.DEFAULT_ROOT_SERVICE_NAME.getValue() },
                { application, "",           "REST::JSON",   Constants.DEFAULT_ROOT_SERVICE_NAME.getValue() },
                { application, serviceName,  "SOAP::XML",    capServiceName },
                { application, serviceName,  "REST::JSON",   serviceName },
                { application, serviceNameWithUnwantedChars,  "REST::JSON",  "restServiceName_subservice_interface" },
                { application, soapServiceNameWithUnwantedChars,  "SOAP::XML",   "SoapServiceName_subservice_interface" }
                //@formatter:on
        };
    }

    @Test(dataProvider = "testGetFormattedServiceNameDataProvider")
    public void testGetFormattedServiceName(final String application, final String serviceName, final String integrationType, final String expectedResult) {
        // FixmE
        ServiceEndpoint cut = new ServiceEndpoint(application, serviceName, "", "integration", 0, integrationType);
        String result = cut.getServiceCallName();
        assertThat(result).isNotNull().isEqualTo(expectedResult);

    }
}