package com.grolinger.java.controller.templatemodel;

/**
 * Contains all variables that are used in the template
 */
public enum ContextVariables {
    COLOR_TYPE("colorType"),
    COLOR_NAME("colorName"),
    CONNECTION_COLOR("connectionColor"),
    COMPONENT_INTEGRATION_TYPE("componentIntegrationType"),
    COMPLETE_INTERFACE_NAME("COMPLETE_INTERFACE_PATH"),
    DATE_CREATED("dateCreated"),
    SEQUENCE_PARTICIPANT_ORDER("sequenceOrderPrio"),
    API_CREATED("API_CREATED"),
    PATH_TO_COMMON_FILE("commonPath"),
    IS_ROOT_SERVICE("isRootService"),
    IS_SOAP_SERVICE("isSoapService"),
    IS_REST_SERVICE("isRestService"),
    APPLICATION_NAME("applicationName"),
    SERVICE_NAME("serviceName"),
    REST("REST"),
    SOAP("Soap"),
    ALIAS("alias"),
    INTERFACE_NAME("interfaceName"),
    CALL_STACK("callStack"),
    CALL_STACK_INCLUDES("callStackIncludes"),
    CALL_INTERFACE_BY("callInterfaceBy"),
    INTERFACE_RESPONSE_TYPE("interfaceResponseType"),
    COMPONENT_NAME("componentNameWithSuffix");


    private String name;

    ContextVariables(final String name) {
        this.name = name;
    }

    public String getName() {
        return this.name;
    }
}
