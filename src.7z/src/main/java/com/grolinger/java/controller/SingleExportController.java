package com.grolinger.java.controller;

import com.grolinger.java.controller.templatemodel.Template;
import com.grolinger.java.service.DataProcessorService;
import com.grolinger.java.service.adapter.importdata.ImportedService;
import com.grolinger.java.service.data.mapper.ColorMapper;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.thymeleaf.context.Context;

import javax.validation.constraints.NotNull;
import java.time.LocalDate;

import static com.grolinger.java.controller.templatemodel.ContextVariables.*;

@Controller
public class SingleExportController {
    private final DataProcessorService dataProcessorService;


    @Autowired
    SingleExportController(DataProcessorService dataProcessorService) {
        this.dataProcessorService = dataProcessorService;

    }

    @ApiOperation(
            value = "Exports a single component stub."
    )
    @GetMapping(path = "/component/{applicationName}/service/{serviceName}/interface/{interfaceName}/color/{colorName}/{integrationType}", produces = "text/html")
    public String singleComponent(Model model, @PathVariable final String applicationName, @PathVariable final String serviceName, @PathVariable final String interfaceName, @ApiParam(allowableValues = "customer,financial,integration,resource,external") @PathVariable final String colorName, @PathVariable final String integrationType, @ApiParam(allowableValues = "1,2") @RequestParam(required = false, defaultValue = "2") String preprocessorVersion) {
        prepareModel(model, applicationName, serviceName, interfaceName, ColorMapper.getDomainColor(colorName), integrationType, null);
        return isVersionTwo(preprocessorVersion) ? Template.COMPONENT_V2.getTemplateURL() : Template.COMPONENT.getTemplateURL();
    }

    @ApiOperation(
            value = "Exports a single component stub."
    )
    @PostMapping(path = "/component", produces = "text/html", consumes = "application/json")
    public String singleComponent(Model model, @NotNull @RequestBody ImportedService importedService, @RequestParam(required = false, defaultValue = "2") String preprocessorVersion) {
        prepareModel(model, importedService.getApplication(), importedService.getServiceName(), importedService.getInterfaceName(), ColorMapper.getDomainColor(importedService.getDomainColor()), importedService.getIntegrationType(), null);
        return isVersionTwo(preprocessorVersion) ? Template.COMPONENT_V2.getTemplateURL() : Template.COMPONENT.getTemplateURL();
    }

    @ApiOperation(
            value = "Exports a single sequence stub."
    )
    @GetMapping(path = "/sequence/{applicationName}/service/{serviceName}/interface/{interfaceName}/color/{colorName}/{integrationType}/order/{orderPrio}")
    public String singleSequence(Model model, @PathVariable final String applicationName, @PathVariable final String serviceName, @PathVariable final String interfaceName, @ApiParam(allowableValues = "customer,financial,integration,resource,external") @PathVariable final String colorName, @PathVariable final String integrationType, @PathVariable final int orderPrio, @ApiParam(allowableValues = "1,2") @RequestParam(required = false, defaultValue = "2") String preprocessorVersion) {
        prepareModel(model, applicationName, serviceName, interfaceName, ColorMapper.getDomainColor(colorName), integrationType, orderPrio);
        return isVersionTwo(preprocessorVersion) ? Template.SEQUENCE_V2.getTemplateURL() : Template.SEQUENCE.getTemplateURL();
    }

    @ApiOperation(
            value = "Exports a single sequence stub."
    )
    @PostMapping(path = "/sequence", produces = "text/html", consumes = "application/json")
    public String singleSequence(Model model, @NotNull @RequestBody ImportedService importedService, @RequestParam(required = false, defaultValue = "2") String preprocessorVersion) {
        prepareModel(model, importedService.getApplication(), importedService.getServiceName(), importedService.getInterfaceName(), ColorMapper.getDomainColor(importedService.getDomainColor()), importedService.getIntegrationType(), null);
        return isVersionTwo(preprocessorVersion) ? Template.SEQUENCE_V2.getTemplateURL() : Template.SEQUENCE.getTemplateURL();
    }

    /**
     * Prepares the model to export
     *
     * @param model
     * @param applicationName
     * @param serviceName
     * @param interfaceName
     * @param colorName
     * @param integrationType
     * @param orderPrio
     */
    void prepareModel(Model model, @PathVariable String applicationName, @PathVariable String serviceName, @PathVariable String interfaceName, @PathVariable String colorName, @PathVariable String integrationType, @PathVariable Integer orderPrio) {
        model.addAttribute(DATE_CREATED.getName(), LocalDate.now());
        //TODO Call Stack
        // TODO fix all
        String systemType = "application";
        Context context = dataProcessorService.processContextOfApplication(colorName, integrationType, systemType, applicationName, serviceName, interfaceName, orderPrio);

        model.addAttribute(PATH_TO_COMMON_FILE.getName(), context.getVariable(PATH_TO_COMMON_FILE.getName()));
        model.addAttribute(APPLICATION_NAME.getName(), context.getVariable(APPLICATION_NAME.getName()));
        model.addAttribute(ALIAS.getName(), context.getVariable(ALIAS.getName()));
        model.addAttribute(SERVICE_NAME.getName(), context.getVariable(SERVICE_NAME.getName()));
        model.addAttribute(INTERFACE_NAME.getName(), context.getVariable(INTERFACE_NAME.getName()));
        model.addAttribute(COLOR_TYPE.getName(), context.getVariable(COLOR_TYPE.getName()));
        model.addAttribute(CONNECTION_COLOR.getName(), context.getVariable(CONNECTION_COLOR.getName()));
        model.addAttribute(COLOR_NAME.getName(), context.getVariable(COLOR_NAME.getName()));
        if (orderPrio != null) {
            model.addAttribute(SEQUENCE_PARTICIPANT_ORDER.getName(), orderPrio);
        }
        model.addAttribute(IS_ROOT_SERVICE.getName(), context.getVariable(IS_ROOT_SERVICE.getName()));
        model.addAttribute(IS_SOAP_SERVICE.getName(), context.getVariable(IS_SOAP_SERVICE.getName()));
        model.addAttribute(COMPONENT_INTEGRATION_TYPE.getName(), context.getVariable(COMPONENT_INTEGRATION_TYPE.getName()));
        model.addAttribute(COMPLETE_INTERFACE_NAME.getName(), context.getVariable(COMPLETE_INTERFACE_NAME.getName()));
        model.addAttribute(API_CREATED.getName(), context.getVariable(API_CREATED.getName()));


    }

    private boolean isVersionTwo(@RequestParam(required = false) String version) {
        return version != null && version.equals("2");
    }
}