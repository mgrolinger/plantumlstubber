package com.grolinger.java.service.adapter.importdata;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImportedService {
    private String application;
    private String customAlias;
    private String systemType;
    private String integrationType;
    private String domainColor;
    private Integer orderPrio;
    private String serviceName;
    private String interfaceName;
}
