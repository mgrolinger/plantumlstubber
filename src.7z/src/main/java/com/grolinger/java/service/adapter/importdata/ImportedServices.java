package com.grolinger.java.service.adapter.importdata;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.LinkedHashMap;
import java.util.Map;

@Getter
@Setter
@Builder
public class ImportedServices {
    private String application;
    private String customAlias;
    @Builder.Default
    private String systemType = "application";
    private String integrationType;
    private String domainColor;
    private String orderPrio;
    private LinkedHashMap<String,LinkedHashMap<String,String[]>> services;
}
