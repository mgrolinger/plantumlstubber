package com.grolinger.java.service.adapter;

import com.grolinger.java.config.Loggable;
import com.grolinger.java.controller.templatemodel.DiagramType;
import com.grolinger.java.service.data.export.ComponentFile;
import com.grolinger.java.service.data.export.ExampleFile;
import com.grolinger.java.service.data.InterfaceEndpoint;
import com.grolinger.java.service.data.ServiceEndpoint;
import org.thymeleaf.context.Context;

import java.io.IOException;
import java.util.Map;

public interface FileService extends Loggable {
    String createServiceDirectory(final String basePath, final ServiceEndpoint serviceEndpoint) throws IOException;

    void writeDefaultCommonFile(final String basePath, final DiagramType diagramType) throws IOException;

    void writeExampleFile(final String basePath, final String applicationName, final String exampleFile);

    ExampleFile writeInterfaceFile(final String currentPath, final ServiceEndpoint serviceEndpoint, final InterfaceEndpoint currentInterface, Context context, ExampleFile exampleFile);

    void createParentDir(final String fullPath);

    String createDirectory(final String basePath, String path, Map<String, String> dirsCreate, final String applicationName);

    String getRelativeCommonPath(final String applicationName, final String serviceName, final String interfaceName);

    String getRelativeCommonPath(final String serviceName);

    void writeComponentFile(final DiagramType diagramType, ComponentFile componentFile) throws IOException;
}
