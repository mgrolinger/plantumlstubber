package com.grolinger.java.service.data.mapper;

import javax.validation.constraints.NotNull;

public final class ColorMapper {

    public static String getDomainColor(@NotNull final String colorName) {
        return colorName.toUpperCase() + "_DOMAIN_COLOR";
    }

    public static String getConnectionColor(@NotNull final String colorName) {
        return colorName.toUpperCase() + "_DOMAIN_COLOR_CONNECTION";
    }

    public static String getStereotype(final String colorName) {
        return "<<" + colorName + ">>";
    }
}
