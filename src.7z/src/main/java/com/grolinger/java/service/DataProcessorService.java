package com.grolinger.java.service;

import com.grolinger.java.controller.templatemodel.DiagramType;
import com.grolinger.java.controller.templatemodel.Template;
import com.grolinger.java.controller.templatemodel.TemplateContent;
import com.grolinger.java.service.data.ApplicationEndpoint;
import org.thymeleaf.context.Context;

import java.io.IOException;
import java.util.List;

public interface DataProcessorService {
    Context processContextOfApplication(String colorName, String integrationType,  String systemType, String applicationName, String serviceName, String interfaceName, Integer orderPrio);

    void processApplication(final List<ApplicationEndpoint> applicationList, final DiagramType diagramType) throws IOException;
}
