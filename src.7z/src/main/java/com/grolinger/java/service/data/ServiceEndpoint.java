package com.grolinger.java.service.data;

import com.grolinger.java.controller.templatemodel.Constants;
import com.grolinger.java.service.NameService;
import com.grolinger.java.service.data.mapper.SystemType;
import lombok.Getter;
import org.springframework.util.StringUtils;

import java.util.LinkedList;
import java.util.List;

import static com.grolinger.java.controller.templatemodel.Constants.*;
import static com.grolinger.java.controller.templatemodel.ContextVariables.SOAP;
import static com.grolinger.java.service.NameService.replaceUnwantedCharacters;

@Getter
public class ServiceEndpoint {
    private String applicationName;
    private SystemType systemType;
    private String serviceName;
    private String servicePath;
    private int orderPrio;
    private String domainColor;
    private String integrationType;
    private boolean soapService;
    private String commonPath;
    private String serviceCallName;
    private List<InterfaceEndpoint> interfaceEndpoints = new LinkedList<>();

    public ServiceEndpoint(final String applicationName, final String serviceName, final String systemType, final String domainColor, final int orderPrio, final String integrationType) {
        this.applicationName = StringUtils.capitalize(replaceUnwantedCharacters(applicationName, false));
        if (StringUtils.isEmpty(systemType)) {
            this.systemType = SystemType.COMPONENT;
        } else {
            this.systemType = SystemType.getFrom(systemType.toLowerCase());
        }
        this.orderPrio = orderPrio;
        this.domainColor = domainColor;
        this.integrationType = integrationType;
        // This needs to be set before setting the serviceCallName
        this.soapService = isCurrentServiceASoapService(integrationType);

        if (StringUtils.isEmpty(serviceName) || EMPTY.getValue().equalsIgnoreCase(serviceName)) {
            this.serviceName = "";
            this.servicePath = "";
            setServiceCallName("");
            commonPath = DIR_UP.getValue();
        } else {
            this.servicePath = replaceUnwantedCharacters(serviceName, true);
            if (!servicePath.endsWith(SLASH.getValue())) {
                this.servicePath = this.servicePath + SLASH.getValue();
            }
            this.serviceName = replaceUnwantedCharacters(serviceName, true);
            setServiceCallName(this.serviceName);
            commonPath = getRelativeCommonPath(serviceName);
        }

    }


    private String getRelativeCommonPath(final String serviceName) {
        StringBuilder cp = new StringBuilder();
        if (serviceName.contains(Constants.SLASH.getValue())) {
            for (int i = 0; i <= serviceName.split(Constants.SLASH.getValue()).length; i++) {
                cp.append(DIR_UP.getValue());
            }
        } else {
            cp.append(DIR_UP.getValue())
                    .append(DIR_UP.getValue());
        }
        return cp.toString();
    }


    private void setServiceCallName(final String unformattedServiceName) {
        if (StringUtils.isEmpty(unformattedServiceName) || EMPTY.getValue().equalsIgnoreCase(unformattedServiceName)) {
            this.serviceCallName = DEFAULT_ROOT_SERVICE_NAME.getValue();
        } else {
            // Capitalize only Soap services
            this.serviceCallName = soapService ? StringUtils.capitalize(unformattedServiceName) : unformattedServiceName;

            if (serviceName.contains(SLASH.getValue()) || serviceName.contains(HYPHEN.getValue())) {
                this.serviceCallName = NameService.replaceUnwantedCharacters(serviceCallName, false);
            } else {
                this.serviceCallName = serviceCallName;
            }
        }
    }

    private boolean isCurrentServiceASoapService(final String integrationType) {
        boolean isSoapService = false;
        if (!StringUtils.isEmpty(integrationType)) {
            isSoapService = integrationType.toUpperCase().contains(SOAP.getName().toUpperCase());
        }
        return isSoapService;
    }
}
