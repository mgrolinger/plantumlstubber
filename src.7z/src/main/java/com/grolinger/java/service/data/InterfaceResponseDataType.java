package com.grolinger.java.service.data;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
public enum InterfaceResponseDataType {
    XML("XML"),
    JSON("JSON"),
    HTML("HTML"),
    JDBC("Resultset"),
    TODO("TODO");
    @Getter
    private String getDataType;

    public static InterfaceResponseDataType getFrom(final String responseType) {
        InterfaceResponseDataType result = TODO;
        for (InterfaceResponseDataType responseDataType : InterfaceResponseDataType.values()) {
            // Match input to enum because enum string is most likely shorter REST::JSON <-> JSON
            if (responseType.toUpperCase().contains(responseDataType.name())) {
                result = responseDataType;
            }
        }
        return result;
    }

}
