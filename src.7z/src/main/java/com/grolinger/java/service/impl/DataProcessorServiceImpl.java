package com.grolinger.java.service.impl;

import com.grolinger.java.config.Loggable;
import com.grolinger.java.controller.templatemodel.DiagramType;
import com.grolinger.java.controller.templatemodel.Template;
import com.grolinger.java.controller.templatemodel.TemplateContent;
import com.grolinger.java.service.NameService;
import com.grolinger.java.service.adapter.FileService;
import com.grolinger.java.service.data.ApplicationEndpoint;
import com.grolinger.java.service.data.InterfaceEndpoint;
import com.grolinger.java.service.data.ServiceEndpoint;
import com.grolinger.java.service.data.export.ComponentFile;
import com.grolinger.java.service.data.export.ExampleFile;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.context.Context;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.grolinger.java.controller.templatemodel.TemplateContent.COMPONENTV2_HEADER;
import static com.grolinger.java.controller.templatemodel.TemplateContent.SEQUENCEV2_HEADER;

@Service
@RequiredArgsConstructor(onConstructor = @__(@Autowired))
public class DataProcessorServiceImpl implements Loggable, com.grolinger.java.service.DataProcessorService {
    private final FileService fileService;

    @Override
    public Context processContextOfApplication(String colorName, String integrationType, String systemType, String applicationName, String serviceName, String interfaceName, Integer orderPrio) {
        ServiceEndpoint serviceEndpoint = new ServiceEndpoint(applicationName, serviceName, systemType, colorName, orderPrio, integrationType);
        return new ContextSpec().builder()
                .withColorName(colorName)
                .withIntegrationType(integrationType)
                .withApplicationName(serviceEndpoint.getApplicationName())
                .withPreformattedServiceName(serviceEndpoint.getServiceCallName())
                .withInterfaceName(NameService.replaceUnwantedCharacters(interfaceName, false))
                .withOrderPrio(orderPrio)
                .withCommonPath(fileService.getRelativeCommonPath(applicationName, serviceName, interfaceName))
                .getContext();
    }

    @Override
    public void processApplication(List<ApplicationEndpoint> pumlComponents, DiagramType diagramType) throws IOException {
        Map<String, String> dirsCreate = new HashMap<>();
        ComponentFile componentFile = new ComponentFile(diagramType);
        for (ApplicationEndpoint pumlComponent : pumlComponents) {
            // Prepare example file for every Application
            ExampleFile exampleFile = new ExampleFile(getTemplate(diagramType), getTemplateContent(diagramType));
            for (ServiceEndpoint serviceEndpoint : pumlComponent.getServiceEndpoints()) {
                fileService.createDirectory(diagramType.getBasePath(), "", dirsCreate, serviceEndpoint.getApplicationName());

                String path = "";
                componentFile.addComponent(serviceEndpoint);
                ContextSpec.ContextBuilder contextBuilder = new ContextSpec()
                        .builder()
                        .withColorName(serviceEndpoint.getDomainColor())
                        .withIntegrationType(serviceEndpoint.getIntegrationType())
                        .withApplicationName(serviceEndpoint.getApplicationName())
                        .withCustomAlias(pumlComponent.getCustomAlias())
                        .withOrderPrio(serviceEndpoint.getOrderPrio());
                path = processService(diagramType.getBasePath(), dirsCreate, serviceEndpoint, contextBuilder);

                processInterfaces(path, contextBuilder, serviceEndpoint, exampleFile);
            }
            fileService.writeExampleFile(diagramType.getBasePath(), pumlComponent.getName(), exampleFile.getFullFileContent());
        }
        fileService.writeDefaultCommonFile(diagramType.getBasePath(), diagramType);
        fileService.writeComponentFile(diagramType, componentFile);

    }

    private String processService(String basePath, Map<String, String> dirsCreate, ServiceEndpoint serviceEndpoint, ContextSpec.ContextBuilder contextBuilder) throws IOException {
        contextBuilder.withPreformattedServiceName(serviceEndpoint.getServiceCallName());
        logger().info("Processing service:{}_{}", serviceEndpoint.getApplicationName(), serviceEndpoint.getServiceCallName());
        String pathForReturnValue;

        if (!dirsCreate.containsKey(serviceEndpoint.getApplicationName() + serviceEndpoint.getServiceCallName())) {
            // create directory if not done yet
            String path = fileService.createServiceDirectory(basePath, serviceEndpoint);
            dirsCreate.put(serviceEndpoint.getApplicationName() + serviceEndpoint.getServiceCallName(), path);
        }
        contextBuilder.withCommonPath(serviceEndpoint.getCommonPath());
        pathForReturnValue = dirsCreate.get(serviceEndpoint.getApplicationName() + serviceEndpoint.getServiceCallName());

        return pathForReturnValue;
    }

    private void processInterfaces(String path, ContextSpec.ContextBuilder contextBuilder, ServiceEndpoint serviceEndpoint, ExampleFile exampleFile) {
        logger().info("Current path: {}", path);
        for (InterfaceEndpoint currentInterface : serviceEndpoint.getInterfaceEndpoints()) {
            if (currentInterface.hasRelativeCommonPath()) {
                contextBuilder.addToCommonPath(currentInterface.getRelativeCommonPath());
            }
            // ignore call stack information
            logger().info("Extracted interface: {}", currentInterface.getName());
            if (currentInterface.containsPath()) {
                //first create the parent dir and next replace chars
                fileService.createParentDir(path + currentInterface.getName());
            }
            contextBuilder.withInterfaceName(currentInterface.getName());
            contextBuilder.withCallStack(currentInterface);
            contextBuilder.withCallInterfaceBy(currentInterface.getCallMeBy());
            contextBuilder.withReponseDataType(serviceEndpoint.getIntegrationType());

            // Pull context to use it later for export
            exampleFile = fileService.writeInterfaceFile(path, serviceEndpoint, currentInterface, contextBuilder.getContext(), exampleFile);
        }

    }

    private Template getTemplate(final DiagramType diagramType) {
        if (DiagramType.COMPONENT_DIAGRAM_BASE.equals(diagramType)) {
            return Template.COMPONENT_V2;
        }
        return Template.SEQUENCE_V2;

    }

    private TemplateContent getTemplateContent(final DiagramType diagramType) {
        if (DiagramType.COMPONENT_DIAGRAM_BASE.equals(diagramType)) {
            return COMPONENTV2_HEADER;
        }
        return SEQUENCEV2_HEADER;

    }

}
