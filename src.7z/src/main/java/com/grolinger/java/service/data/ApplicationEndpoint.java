package com.grolinger.java.service.data;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.util.List;

@Getter
@Builder
public class ApplicationEndpoint {
    private String name;
    private String customAlias;
    private List<ServiceEndpoint> serviceEndpoints;
}
