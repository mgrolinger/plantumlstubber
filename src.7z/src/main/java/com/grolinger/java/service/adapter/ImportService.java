package com.grolinger.java.service.adapter;

import com.grolinger.java.config.Loggable;
import com.grolinger.java.service.data.ApplicationEndpoint;

import java.util.List;

public interface ImportService extends Loggable {
    List<ApplicationEndpoint> findAllServiceEnpoints();
}
