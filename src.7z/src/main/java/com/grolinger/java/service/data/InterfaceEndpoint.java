package com.grolinger.java.service.data;

import com.grolinger.java.controller.templatemodel.Constants;
import lombok.Getter;

import java.util.Arrays;

import static com.grolinger.java.controller.templatemodel.Constants.SLASH;
import static com.grolinger.java.service.NameService.replaceUnwantedCharacters;


public class InterfaceEndpoint {
    private String originalInterface;
    @Getter
    private String methodName;
    @Getter
    private String name;
    @Getter
    private String interfacePath = "";
    @Getter
    private String formattedName;
    @Getter
    private String[] callStack;
    @Getter
    private String[] callStackForIncludes;
    @Getter
    private String relativeCommonPath = "";
    @Getter
    private String callMeBy;

    public InterfaceEndpoint(final String originalInterfaceName,final String callMeBy) {
        this.originalInterface = originalInterfaceName;
        this.name = extractInterfaceName(originalInterfaceName);
        this.methodName = getMethodName(name);
        this.formattedName = replaceUnwantedCharacters(name, false);
        this.callMeBy = callMeBy.trim().toLowerCase();
        StringBuilder relativeCommonPathBuilder = new StringBuilder();
        for (int i = 0; i < name.chars().filter(ch -> ch == SLASH.getFirstChar()).count(); i++) {
            relativeCommonPathBuilder.append(Constants.DIR_UP.getValue());
        }
        relativeCommonPath = relativeCommonPathBuilder.toString();
    }

    public boolean containsPath() {
        return name.contains(SLASH.getValue());
    }

    public boolean hasRelativeCommonPath() {
        return relativeCommonPath.length() > 0;
    }


    public boolean containsCallStack() {
        return originalInterface.contains("->") && callStack != null && callStack.length > 0;
    }

    private String extractInterfaceName(final String interfaceName) {
        String calledInterfaceName;
        if (interfaceName.contains("->")) {
            String[] currentCallStack = interfaceName.split("->");
            calledInterfaceName = currentCallStack[0];
            this.callStack = Arrays.copyOfRange(currentCallStack, 1, currentCallStack.length);
            int i = 0;
            callStackForIncludes = new String[currentCallStack.length - 1];
            for (String call : callStack) {
                callStackForIncludes[i] = call;
                callStack[i] = call.replaceAll("[/\\.]", "_");
                callStackForIncludes[i] = callStackForIncludes[i].replaceAll("[_\\.]", "/");
                i++;
            }
        } else {
            calledInterfaceName = interfaceName;
        }
        return calledInterfaceName;
    }

    private String getMethodName(final String currentInterfaceName) {
        if (currentInterfaceName.contains(SLASH.getValue())) {
            char[] currentInterfacePath = new char[currentInterfaceName.length()];
            currentInterfaceName.getChars(0, currentInterfaceName.lastIndexOf(SLASH.getValue()), currentInterfacePath, 0);
            char[] endpoint = new char[currentInterfaceName.length()];
            currentInterfaceName.getChars(currentInterfaceName.lastIndexOf(SLASH.getValue()) + 1, currentInterfaceName.length(), endpoint, 0);
            methodName = new String(endpoint).trim();
        } else {
            methodName = currentInterfaceName;
        }
        return methodName;
    }
}
