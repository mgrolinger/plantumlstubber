package com.grolinger.java.service.impl;

import com.grolinger.java.config.Loggable;
import com.grolinger.java.controller.templatemodel.Constants;
import com.grolinger.java.controller.templatemodel.ContextVariables;
import com.grolinger.java.service.data.InterfaceEndpoint;
import com.grolinger.java.service.data.InterfaceResponseDataType;
import com.grolinger.java.service.data.mapper.ColorMapper;
import org.springframework.util.StringUtils;
import org.thymeleaf.context.Context;

import java.time.LocalDate;

import static com.grolinger.java.controller.templatemodel.Constants.EMPTY;
import static com.grolinger.java.controller.templatemodel.ContextVariables.*;
import static com.grolinger.java.service.NameService.replaceUnwantedCharacters;

public final class ContextSpec {


    public ColorBuilder builder() {
        return new ContextBuilderImpl(new Context());
    }


    interface ColorBuilder {
        IntegrationTypeBuilder withColorName(final String colorName);
    }

    interface IntegrationTypeBuilder {
        ApplicationNameBuilder withIntegrationType(final String integrationType);
    }

    interface ApplicationNameBuilder {
        ContextBuilder withApplicationName(final String applicationName);
    }

    public interface ContextBuilder {
        ContextBuilder withOrderPrio(final Integer orderNumber);

        ContextBuilder withPreformattedServiceName(final String serviceName);

        ContextBuilder withCustomAlias(final String customAlias);

        ContextBuilder withInterfaceName(final String interfaceName);

        ContextBuilder withCallStack(final InterfaceEndpoint interfaceEndpoint);

        ContextBuilder withCommonPath(final String commonPath);

        ContextBuilder addToCommonPath(final String commonPath);

        ContextBuilder withCallInterfaceBy(final String callMeBy);

        ContextBuilder withReponseDataType(final String interfaceResponseDataType);

        ContextBuilder with(final ContextVariables variable, final String value);

        Context getContext();
    }

    public class ContextBuilderImpl implements ContextBuilder, ColorBuilder, IntegrationTypeBuilder, ApplicationNameBuilder, Loggable {
        private Context context;

        ContextBuilderImpl(Context context) {
            this.context = context;
            context.setVariable(DATE_CREATED.getName(), LocalDate.now());
            // set the default to true to prevent NullPointer, so called root services have only the applicationName and interfaceName set
            context.setVariable(IS_ROOT_SERVICE.getName(), true);
            // default is the same directory
            context.setVariable(PATH_TO_COMMON_FILE.getName(), "");
        }

        //FIXME hand over interfaceEndpoint and do the magic here
        @Override
        public IntegrationTypeBuilder withColorName(final String color) {
            ColorMapper colorMapper = new ColorMapper();
            context.setVariable(COLOR_TYPE.getName(), colorMapper.getStereotype(color));
            context.setVariable(COLOR_NAME.getName(), colorMapper.getDomainColor(color));
            context.setVariable(CONNECTION_COLOR.getName(), colorMapper.getConnectionColor(color));
            return this;
        }

        @Override
        public ApplicationNameBuilder withIntegrationType(final String integrationType) {
            String formattedIntegrationType = "";
            context.setVariable(IS_SOAP_SERVICE.getName(), false);
            if (!StringUtils.isEmpty(integrationType)) {
                formattedIntegrationType = "INTEGRATION_TYPE(" + integrationType + ")";
                context.setVariable(IS_SOAP_SERVICE.getName(), integrationType.toUpperCase().contains(SOAP.getName().toUpperCase()));
                context.setVariable(IS_REST_SERVICE.getName(), integrationType.toUpperCase().contains(REST.getName().toUpperCase()));
            }
            context.setVariable(COMPONENT_INTEGRATION_TYPE.getName(), formattedIntegrationType);
            return this;
        }

        @Override
        public ContextBuilder withApplicationName(final String applicationName) {
            context.setVariable(APPLICATION_NAME.getName(), StringUtils.capitalize(applicationName));
            String alias = applicationName.toLowerCase();
            if (StringUtils.isEmpty(context.getVariable(ALIAS.getName()))) {
                context.setVariable(ALIAS.getName(), alias);
            }
            return this;
        }

        @Override
        public ContextBuilder withCustomAlias(final String alias) {
            context.setVariable(ALIAS.getName(), alias);
            return this;
        }

        @Override
        public ContextBuilder withPreformattedServiceName(final String serviceName) {
            if (StringUtils.isEmpty(serviceName) || EMPTY.getValue().equalsIgnoreCase(serviceName)) {
                context.setVariable(SERVICE_NAME.getName(), "");
                context.setVariable(IS_ROOT_SERVICE.getName(), true);
            } else {
                //ServiceName containing dot (.) seems to cause syntax error in generated iuml file
                context.setVariable(SERVICE_NAME.getName(),
                        serviceName.replace(Constants.DOT_SEPARATOR.getValue(), Constants.NAME_SEPARATOR.getValue()));

                context.setVariable(IS_ROOT_SERVICE.getName(), false);
            }
            return this;
        }

        @Override
        public ContextBuilder withInterfaceName(final String interfaceName) {
            final String cleanedInterfaceName = replaceUnwantedCharacters(interfaceName, false);
            context.setVariable(INTERFACE_NAME.getName(), cleanedInterfaceName);
            String applicationName = (String) context.getVariable(APPLICATION_NAME.getName());
            String serviceName = (String) context.getVariable(SERVICE_NAME.getName());
            boolean isRoot = (boolean) context.getVariable(IS_ROOT_SERVICE.getName());
            context.setVariable(COMPLETE_INTERFACE_NAME.getName(),
                    StringUtils.capitalize(applicationName) + (isRoot ? "" : capitalizePathParts(serviceName)) +
                            StringUtils.capitalize(cleanedInterfaceName.replaceAll(Constants.NAME_SEPARATOR.getValue(), "")) +
                            "Int");
            context.setVariable(API_CREATED.getName(), applicationName.toUpperCase() +
                    "_API" + (isRoot ? "" : "_" + serviceName.toUpperCase().replaceAll(Constants.SLASH.getValue(), Constants.NAME_SEPARATOR.getValue())) +
                    "_" + cleanedInterfaceName.toUpperCase() +
                    "_CREATED");
            return this;
        }

        @Override
        public ContextBuilder withOrderPrio(final Integer orderWithinSequence) {
            if (orderWithinSequence != null) {
                context.setVariable(SEQUENCE_PARTICIPANT_ORDER.getName(), orderWithinSequence);
            }
            return this;
        }

        @Override
        public ContextBuilder withCommonPath(final String commonPath) {
            context.setVariable(PATH_TO_COMMON_FILE.getName(), commonPath);
            return this;
        }

        @Override
        public ContextBuilder addToCommonPath(final String commonPath) {
            String existingPath = (String) context.getVariable(PATH_TO_COMMON_FILE.getName());
            if (!StringUtils.isEmpty(existingPath)) {
                existingPath = existingPath + commonPath;
            } else {
                existingPath = commonPath;
            }
            context.setVariable(PATH_TO_COMMON_FILE.getName(), existingPath);
            return this;
        }

        @Override
        public ContextBuilder withCallStack(final InterfaceEndpoint interfaceEndpoint) {
            if (interfaceEndpoint.containsCallStack()) {
                context.setVariable(CALL_STACK.getName(), interfaceEndpoint.getCallStack());
                context.setVariable(CALL_STACK_INCLUDES.getName(), interfaceEndpoint.getCallStackForIncludes());
            } else {
                context.removeVariable(CALL_STACK.getName());
                context.removeVariable(CALL_STACK_INCLUDES.getName());
            }
            return this;
        }

        @Override
        public ContextBuilder withCallInterfaceBy(final String callMeBy) {
            context.setVariable(CALL_INTERFACE_BY.getName(), "$" + callMeBy + "Call");
            return this;
        }

        @Override
        public ContextBuilder withReponseDataType(final String interfaceResponseDataType) {
            context.setVariable(INTERFACE_RESPONSE_TYPE.getName(), InterfaceResponseDataType.getFrom(interfaceResponseDataType).getGetDataType());
            return this;
        }

        @Override
        public ContextBuilder with(final ContextVariables contextVariable, final String value) {
            context.setVariable(contextVariable.getName(), value);
            return this;
        }

        public Context getContext() {
            return this.context;
        }

        //TODO add test
        private String capitalizePathParts(final String pathToCapitalize) {
            return capitalizeStringParts(capitalizeStringParts(pathToCapitalize, Constants.SLASH.getValue()), Constants.NAME_SEPARATOR.getValue());
        }

        private String capitalizeStringParts(final String pathToCapitalize, final String splitChar) {
            StringBuilder result = new StringBuilder();
            if (!StringUtils.isEmpty(pathToCapitalize)) {
                if (pathToCapitalize.contains(splitChar)) {
                    String[] parts = pathToCapitalize.split(splitChar);
                    for (String part : parts) {
                        result.append(StringUtils.capitalize(part.replaceAll(splitChar, "")));
                    }
                } else {
                    result.append(StringUtils.capitalize(pathToCapitalize));
                }
            }
            return result.toString();
        }

    }
}
