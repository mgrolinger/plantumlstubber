package com.grolinger.java.service.adapter.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.grolinger.java.service.adapter.ImportService;
import com.grolinger.java.service.adapter.importdata.ImportedServices;
import com.grolinger.java.service.data.ApplicationEndpoint;
import com.grolinger.java.service.data.InterfaceEndpoint;
import com.grolinger.java.service.data.ServiceEndpoint;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ReflectionToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.grolinger.java.service.NameService.replaceUnwantedCharacters;

@Service
public class ImportServiceImpl implements ImportService {
    private static final String GLOBAL_FILE_EXPORT_PATH = System.getProperty("user.dir") + File.separator + "target" + File.separator;

    @Override
    public List<ApplicationEndpoint> findAllServiceEnpoints() {
        List<Path> collect = new LinkedList<>();
        // TODO open file chooser for root if args given

        try (Stream<Path> input = Files.walk(Paths.get(GLOBAL_FILE_EXPORT_PATH))) {
            collect = input
                    .filter(Files::isRegularFile)
                    .filter(YamlPredicate::isYamlFile)
                    .collect(Collectors.toList());
        } catch (IOException ioe) {
            logger().error("Failed to find yaml files", ioe);
        }

        if (collect.isEmpty()) {
            logger().warn("No Yaml file found. Please check working directory in run configuration.");
        }

        List<ImportedServices> services = new LinkedList<>();
        for (Path filesToMap : collect) {
            services.addAll(mapYamls(filesToMap));
        }
        Map<String, ApplicationEndpoint> app = new HashMap<>();

        for (ImportedServices importedServices : services) {
            if (importedServices == null || importedServices.getServices() == null) {
                continue;
            }
            int orderPrio = Integer.parseInt(importedServices.getOrderPrio());
            logger().debug("{}, {}, {}", importedServices.getApplication(), importedServices.getSystemType(), importedServices.getOrderPrio());
            final String applicationName = replaceUnwantedCharacters(importedServices.getApplication(), false);
            ApplicationEndpoint pumlComponent;
            if (app.containsKey(applicationName)) {
                pumlComponent = app.get(applicationName);
            } else {
                String alias = StringUtils.isEmpty(importedServices.getCustomAlias()) ?
                        replaceUnwantedCharacters(importedServices.getApplication().toLowerCase(), false) :
                        importedServices.getCustomAlias();
                pumlComponent = ApplicationEndpoint.builder().name(applicationName)
                        .customAlias(alias)
                        .serviceEndpoints(new LinkedList<>())
                        .build();
            }

            List<ServiceEndpoint> serviceEndpoints = new LinkedList<>();
            // Iterate over Services.<REST|SOAP|...>
            for (String interfacesIntegrationType : importedServices.getServices().keySet()) {
                String path = "";
                LinkedHashMap<String, String[]> serviceList = importedServices.getServices().get(interfacesIntegrationType);
                // Iterate over the services itself
                for (Map.Entry<String, String[]> serviceName : serviceList.entrySet()) {
                    String[] services1 = serviceName.getValue();
                    ServiceEndpoint serviceEndpoint = new ServiceEndpoint(applicationName, serviceName.getKey(), importedServices.getSystemType(), importedServices.getDomainColor(), orderPrio, importedServices.getIntegrationType());
                    //Interfaces
                    logger().info("Current path: {}", path);
                    for (String interfaceName : services1) {
                        InterfaceEndpoint interfaceEndpoint = new InterfaceEndpoint(interfaceName, interfacesIntegrationType);
                        // ignore call stack information
                        logger().info("Extracted interface: {}", interfaceEndpoint.getName());
                        serviceEndpoint.getInterfaceEndpoints().add(interfaceEndpoint);
                    }
                    serviceEndpoints.add(serviceEndpoint);
                }
            }
            pumlComponent.getServiceEndpoints().addAll(serviceEndpoints);
            app.put(applicationName, pumlComponent);
        }
        // UNwrap from map
        return new LinkedList<>(app.values());
    }

    private List<ImportedServices> mapYamls(final Path path) {
        List<ImportedServices> importedServicesList = new LinkedList<>();
        ObjectMapper mapper = new ObjectMapper(new YAMLFactory());
        try {
            ImportedServices importedServices = mapper.readValue(path.toFile(), ImportedServices.class);
            if (logger().isInfoEnabled()) {
                logger().info(ReflectionToStringBuilder.toString(importedServices, ToStringStyle.MULTI_LINE_STYLE));
            }
            importedServicesList.add(importedServices);
        } catch (Exception e) {
            //Do nothing
            logger().error("mapYamls exception: {}", e.getMessage());
        }
        return importedServicesList;
    }

}
