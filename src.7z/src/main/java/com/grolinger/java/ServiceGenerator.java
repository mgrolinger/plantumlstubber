package com.grolinger.java;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {"com.grolinger.java"})
public class ServiceGenerator {
    private static final Logger logger = LoggerFactory.getLogger(ServiceGenerator.class);
    public static void main(String[] args) {

        SpringApplication.run(ServiceGenerator.class, args);
        logger.info("Swagger accessible via http://localhost:19191/swagger-ui.html#/");
    }

}
